# -*- coding: utf-8 -*-

def test_my_add(x1: float, x2: float) -> float:
    """ 足し算を行う

    Argumentns:
        :x1: float
            数値1

        :x2: float
            数値2

    Returns:
        :y: float
            x1+x2
    """

    y = x1 + x2
    return y