# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['packaging_tutorial']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'packaging-tutorial',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 's1830134',
    'author_email': 's1830134@s.tsukuba.ac.jp',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
